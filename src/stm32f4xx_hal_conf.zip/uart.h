#ifndef UART_H
#define UART_H

void uart_init(void);

// Note: No other public functions needed;
//       all access via stdin and stdout

#endif