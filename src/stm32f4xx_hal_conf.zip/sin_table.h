#ifndef SIN_TABLE_H
#define SIN_TABLE_H

void sin_table_cmd(int, char *[]);
void sin_table_task(void const *);

#endif