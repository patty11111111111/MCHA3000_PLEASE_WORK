#ifndef LOG_DATA_H
#define LOG_DATA_H

void log_data_cmd(int, char *[]);
void log_data_task(void const *);

#endif